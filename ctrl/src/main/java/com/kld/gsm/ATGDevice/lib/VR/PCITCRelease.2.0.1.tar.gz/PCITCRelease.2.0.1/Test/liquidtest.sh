#!/bin/sh
rm -f ./liquidtest ./liquidtest.o core*
echo "Compiling liquidtest.c ..."
gcc liquidtest.c -I../VRIF/PCITC/ -Wall -g -lm -lc -lpthread -o liquidtest -ldl
echo "Compile liquidtest.c over"

echo "Execute ./liquidtest ..."

if [ $# -gt 0 ]; then
	./liquidtest $1
	exit 0
else
	./liquidtest
	exit 0
fi

if [ $# -gt 1 ]; then
	./liquidtest $1 $2
	exit 0
fi

if [ $# -gt 2 ]; then
	./liquidtest $1 $2 $3
	exit 0
fi

if [ $# -gt 3 ]; then
	./liquidtest $1 $2 $3 $4
	exit 0
fi

if [ $# -gt 4 ]; then
	./liquidtest $1 $2 $3 $4 $5
	exit 0
fi

if [ $# -gt 5 ]; then
	./liquidtest $1 $2 $3 $4 $5 $6
	exit 0
fi

if [ $# -gt 6 ]; then
	./liquidtest $1 $2 $3 $4 $5 $6 $7
	exit 0
fi

if [ $# -gt 7 ]; then
	./liquidtest $1 $2 $3 $4 $5 $6 $7 $8
	exit 0
fi

if [ $# -gt 8 ]; then
	./liquidtest $1 $2 $3 $4 $5 $6 $7 $8 $9
	exit 0
fi

if [ $# -gt 9 ]; then
	echo "Too many parameters"
	exit 0
fi
