#include <dlfcn.h>
#include <stdio.h>
#include <stdlib.h>
#include <signal.h>
#include <malloc.h>
#include <unistd.h>
#include <string.h>
#include <time.h>
#include <pthread.h>
#include "VRATGInterface.h"

#ifdef __LAB_DEBUGGING__
static const char* pszSharedObjectFile = "../VRIF/PCITC/ATGLib.so.2.0.0";
#else
static const char* pszSharedObjectFile = "../VRIF/PCITC/ATGLib.so";
#endif // #ifdef __LAB_DEBUGGING__

static const int g_iOilCans = 4;

static const int g_iLeakTestDuration = 3;
static const double g_dbLeakTestRate = 0.38;

static const int g_iPollInterval = 30;
static const int g_iOperationInterval = 600 + 180;

static const char* g_pszDeviceType = "VR_TLS-4";
static const int g_iConnMode = CommunicationMode_Ethernet;

static const char* g_pszSerialAddress = "/dev/ttyS0";
static const char* g_pszSerialBaudRate = "9600";
static const char* g_pszSerialStopBit = "1";
static const char* g_pszSerialCheckBit = "O";
static const char* g_pszSerialDataBit = "7";

static const char* g_pszIPAddress = "10.20.34.21";
static const char* g_pszIPPort = "10001";

static const char* g_pszLogPath = "./log";

static const time_t g_tStartTimeOffset = -90 * 24 * 3600;
static const int g_iReqCount = 300;

static const int g_iMaximumErrors = 1000;

static int g_runflag = 1;

void signal_interrupt(int sig)
{
   if (g_runflag != 0)
   {
      g_runflag = 0;   
      printf("Exit by <Ctrl + C> pressed\r\n");
   }
}

int start_liquid(void)
{
   int ret = 0, i = 0;
   static int iImmediately = 1;
   struct atg_startliquid_in_t atgStartLiquidIn;
   struct atg_startliquid_data_in_t atgStartLiquidDataIn[g_iOilCans];
   char* pszResult = NULL;
   struct tm* p = NULL;
   time_t t = 0;

   atgStartLiquidIn.pLiquidData = atgStartLiquidDataIn;
   atgStartLiquidIn.uCount = g_iOilCans;

   printf("\r\n--------------------------------------------\r\n");
   t = time(NULL);
   p = localtime(&t);
   printf("Current time: %04d-%02d-%02d %02d:%02d:%02d\r\n\r\n", p->tm_year + 1900,
                                                                 p->tm_mon + 1,    
                                                                 p->tm_mday,       
                                                                 p->tm_hour,       
                                                                 p->tm_min,        
                                                                 p->tm_sec); 
   for (i = 0; i < atgStartLiquidIn.uCount; i++)
   {      
      atgStartLiquidIn.pLiquidData[i].uOilCanNo = i + 1;
      atgStartLiquidIn.pLiquidData[i].uTestType = LiquidTest_StaticLiquidDetect;
      t = time(NULL);
      t += (iImmediately % 2) ? 0 : 200;
      p = localtime(&t);
      sprintf(atgStartLiquidIn.pLiquidData[i].strDateTime, "%04d%02d%02d%02d%02d%02d", p->tm_year + 1900,
                                                                                       p->tm_mon + 1,    
                                                                                       p->tm_mday,       
                                                                                       p->tm_hour,       
                                                                                       p->tm_min,        
                                                                                       p->tm_sec);       
      atgStartLiquidIn.pLiquidData[i].uTestDuration = g_iLeakTestDuration;
      atgStartLiquidIn.pLiquidData[i].fTestRate = g_dbLeakTestRate;

      printf("Oil can %d start liquid test, type = %d, start time \"%s\", duration = %d, rate = %.2f\r\n", atgStartLiquidIn.pLiquidData[i].uOilCanNo, 
                                                                                                           atgStartLiquidIn.pLiquidData[i].uTestType,
                                                                                                           atgStartLiquidIn.pLiquidData[i].strDateTime,
                                                                                                           atgStartLiquidIn.pLiquidData[i].uTestDuration,
                                                                                                           atgStartLiquidIn.pLiquidData[i].fTestRate);
   }
      
   ret = atg_operate(ATG_OPE_STARTLIQUID, &atgStartLiquidIn, (void**)&pszResult);
   if (ret != 0)
   {
      printf("\r\nStart liquid failed. atg_operate(%s, %08X, %08X) = %d", ATG_OPE_STARTLIQUID, (int)&atgStartLiquidIn, (int)&pszResult, ret);
      if (pszResult != NULL)
      {
         printf("\r\nResult is \"%s\"\r\n", pszResult);
      }
   }
   else
   {
      printf("\r\n[-> Start liquid\r\n");
      printf("============================================\r\n");
      printf("Successful\r\n\r\n");
      iImmediately = (iImmediately + 1) % 2;
   }
   if (pszResult != NULL)
   {
      free(pszResult);
   }

   return ret;
}

int stop_liquid(void)
{
   int ret = 0, i = 0;
   struct atg_stopliquid_in_t atgStopLiquidIn;
   struct atg_stopliquid_data_in_t atgStopLiquidDataIn[g_iOilCans];
   struct atg_stopliquid_out_t* pAtgStopLiquid = NULL;   
   struct tm* p = NULL;
   time_t t = 0;

   atgStopLiquidIn.pLiquidData = atgStopLiquidDataIn;
   atgStopLiquidIn.uCount = g_iOilCans;

   printf("\r\n--------------------------------------------\r\n");
   t = time(NULL);
   p = localtime(&t);
   printf("Current time: %04d-%02d-%02d %02d:%02d:%02d\r\n\r\n", p->tm_year + 1900,
                                                                 p->tm_mon + 1,    
                                                                 p->tm_mday,       
                                                                 p->tm_hour,       
                                                                 p->tm_min,        
                                                                 p->tm_sec); 
   for (i = 0; i < atgStopLiquidIn.uCount; i++)
   {      
      atgStopLiquidIn.pLiquidData[i].uOilCanNo = i + 1;
      atgStopLiquidIn.pLiquidData[i].uTestType = LiquidTest_StaticLiquidDetect;

      printf("Oil can %d stop liquid test type = %d\r\n", atgStopLiquidIn.pLiquidData[i].uOilCanNo, 
                                                          atgStopLiquidIn.pLiquidData[i].uTestType);
   }
      
   ret = atg_operate(ATG_OPE_STOPLIQUID, &atgStopLiquidIn, (void**)&pAtgStopLiquid);
   if (ret != 0)
   {
      printf("\r\nStop liquid failed. atg_operate(%s, %08X, %08X) = %d\r\n", ATG_OPE_STOPLIQUID, (int)&atgStopLiquidIn, (int)&pAtgStopLiquid, ret);
   }
   else
   {
      if (pAtgStopLiquid != NULL)
      {
         if (pAtgStopLiquid->pLiquidData != NULL)   
         {
            for (i = 0; i < pAtgStopLiquid->uRetCount; i++)
            {
               printf("\r\n[-> Oil in count = %d\r\n", pAtgStopLiquid->uRetCount);
               printf("============================================\r\n");
               printf("Liquid report [%d]\r\n\r\n", i + 1);
               printf("Oil Can No         = %d\r\n", pAtgStopLiquid->pLiquidData[i].uOilCanNo);
               printf("Reveal status      = %d\r\n", pAtgStopLiquid->pLiquidData[i].uRevealStatus);
               printf("Reveal rate        = %f\r\n", pAtgStopLiquid->pLiquidData[i].fRevealRate);
               printf("Start Date         = %s\r\n", pAtgStopLiquid->pLiquidData[i].strStartDate);
               printf("Start Time         = %s\r\n", pAtgStopLiquid->pLiquidData[i].strStartTime);
               printf("Start Oil Height   = %f\r\n", pAtgStopLiquid->pLiquidData[i].fStartOilHeight);
               printf("Start Water Height = %f\r\n", pAtgStopLiquid->pLiquidData[i].fStartWaterHeight);
               printf("Start Oil Temp.    = %f\r\n", pAtgStopLiquid->pLiquidData[i].fStartOilTemp);
               printf("Start Oil Temp1    = %f\r\n", pAtgStopLiquid->pLiquidData[i].fStartOilTemp1);
               printf("Start Oil Temp2    = %f\r\n", pAtgStopLiquid->pLiquidData[i].fStartOilTemp2);
               printf("Start Oil Temp3    = %f\r\n", pAtgStopLiquid->pLiquidData[i].fStartOilTemp3);
               printf("Start Oil Temp4    = %f\r\n", pAtgStopLiquid->pLiquidData[i].fStartOilTemp4);
               printf("Start Oil Temp5    = %f\r\n", pAtgStopLiquid->pLiquidData[i].fStartOilTemp5);
               printf("Start Oil Cubage   = %f\r\n", pAtgStopLiquid->pLiquidData[i].fStartOilCubage);
               printf("Start Oil Stand Cubage = %f\r\n", pAtgStopLiquid->pLiquidData[i].fStartOilStandCubage);
               printf("Start Empty Cubage = %f\r\n", pAtgStopLiquid->pLiquidData[i].fStartEmptyCubage);
               printf("Start Water Bulk   = %f\r\n", pAtgStopLiquid->pLiquidData[i].fStartWaterBulk);
               printf("End Date           = %s\r\n", pAtgStopLiquid->pLiquidData[i].strEndDate);
               printf("End Time           = %s\r\n", pAtgStopLiquid->pLiquidData[i].strEndTime);
               printf("End Oil Height     = %f\r\n", pAtgStopLiquid->pLiquidData[i].fEndOilHeight);
               printf("End Water Height   = %f\r\n", pAtgStopLiquid->pLiquidData[i].fEndWaterHeight);
               printf("End Oil Temp.      = %f\r\n", pAtgStopLiquid->pLiquidData[i].fEndOilTemp);
               printf("End Oil Temp1      = %f\r\n", pAtgStopLiquid->pLiquidData[i].fEndOilTemp1);
               printf("End Oil Temp2      = %f\r\n", pAtgStopLiquid->pLiquidData[i].fEndOilTemp2);
               printf("End Oil Temp3      = %f\r\n", pAtgStopLiquid->pLiquidData[i].fEndOilTemp3);
               printf("End Oil Temp4      = %f\r\n", pAtgStopLiquid->pLiquidData[i].fEndOilTemp4);
               printf("End Oil Temp5      = %f\r\n", pAtgStopLiquid->pLiquidData[i].fEndOilTemp5);
               printf("End Oil Cubage     = %f\r\n", pAtgStopLiquid->pLiquidData[i].fEndOilCubage);
               printf("End Oil Stand Cubage = %f\r\n", pAtgStopLiquid->pLiquidData[i].fEndOilStandCubage);
               printf("End Empty Cubage = %f\r\n", pAtgStopLiquid->pLiquidData[i].fEndEmptyCubage);
               printf("End Water Bulk   = %f\r\n", pAtgStopLiquid->pLiquidData[i].fEndWaterBulk);
            }
         }
      }
   }
   if (pAtgStopLiquid != NULL)
   {
      if (pAtgStopLiquid->pLiquidData!= NULL)   
      {                           
         free(pAtgStopLiquid->pLiquidData);   
      }                           
      free(pAtgStopLiquid);
   }

   return ret;
}

int get_liquidreport(void)
{
   int ret = 0, i = 0;
   struct atg_liquidreport_in_t atgLiquidReportIn;
   struct atg_liquidreport_data_in_t atgLiquidReportDataIn[g_iOilCans];
   struct atg_liquidreport_out_t* pAtgLiquidReportOut = NULL;   
   struct tm* p = NULL;
   time_t t = 0;

   atgLiquidReportIn.pLiquidData = atgLiquidReportDataIn;
   atgLiquidReportIn.uCount = g_iOilCans;

   printf("\r\n--------------------------------------------\r\n");
   t = time(NULL);
   p = localtime(&t);
   printf("Current time: %04d-%02d-%02d %02d:%02d:%02d\r\n\r\n", p->tm_year + 1900,
                                                                 p->tm_mon + 1,    
                                                                 p->tm_mday,       
                                                                 p->tm_hour,       
                                                                 p->tm_min,        
                                                                 p->tm_sec); 
   for (i = 0; i < atgLiquidReportIn.uCount; i++)
   {      
      atgLiquidReportIn.pLiquidData[i].uOilCanNo = i + 1;
      t = time(NULL);
      t += g_tStartTimeOffset;
      p = localtime(&t);
      sprintf(atgLiquidReportIn.pLiquidData[i].strDateTime, "%04d%02d%02d%02d%02d%02d", p->tm_year + 1900,
                                                                                p->tm_mon + 1,    
                                                                                p->tm_mday,       
                                                                                p->tm_hour,       
                                                                                p->tm_min,        
                                                                                p->tm_sec);       
      atgLiquidReportIn.pLiquidData[i].uTestType = LiquidTest_StaticLiquidDetect;
      atgLiquidReportIn.pLiquidData[i].uReqCount = g_iReqCount;

      printf("Oil can %d liquid report start time \"%s\", test type = %d, required count = %d\r\n", atgLiquidReportIn.pLiquidData[i].uOilCanNo, 
                                                                                                    atgLiquidReportIn.pLiquidData[i].strDateTime,
                                                                                                    atgLiquidReportIn.pLiquidData[i].uTestType,
                                                                                                    atgLiquidReportIn.pLiquidData[i].uReqCount);
   }
      
   ret = atg_operate(ATG_OPE_LIQUIDREPORT, &atgLiquidReportIn, (void**)&pAtgLiquidReportOut);
   if (ret != 0)
   {
      printf("\r\nGet liquid report failed. atg_operate(%s, %08X, %08X) = %d\r\n", ATG_OPE_LIQUIDREPORT, (int)&atgLiquidReportIn, (int)&pAtgLiquidReportOut, ret);
   }
   else
   {
      if (pAtgLiquidReportOut != NULL)
      {
         if (pAtgLiquidReportOut->pLiquidData != NULL)   
         {
            for (i = 0; i < pAtgLiquidReportOut->uRetCount; i++)
            {
               printf("\r\n[-> Oil in count = %d\r\n", pAtgLiquidReportOut->uRetCount);
               printf("============================================\r\n");
               printf("Liquid report [%d]\r\n\r\n", i + 1);
               printf("Oil Can No         = %d\r\n", pAtgLiquidReportOut->pLiquidData[i].uOilCanNo);
               printf("Reveal status      = %d\r\n", pAtgLiquidReportOut->pLiquidData[i].uRevealStatus);
               printf("Reveal rate        = %f\r\n", pAtgLiquidReportOut->pLiquidData[i].fRevealRate);
               printf("Start Date         = %s\r\n", pAtgLiquidReportOut->pLiquidData[i].strStartDate);
               printf("Start Time         = %s\r\n", pAtgLiquidReportOut->pLiquidData[i].strStartTime);
               printf("Start Oil Height   = %f\r\n", pAtgLiquidReportOut->pLiquidData[i].fStartOilHeight);
               printf("Start Water Height = %f\r\n", pAtgLiquidReportOut->pLiquidData[i].fStartWaterHeight);
               printf("Start Oil Temp.    = %f\r\n", pAtgLiquidReportOut->pLiquidData[i].fStartOilTemp);
               printf("Start Oil Temp1    = %f\r\n", pAtgLiquidReportOut->pLiquidData[i].fStartOilTemp1);
               printf("Start Oil Temp2    = %f\r\n", pAtgLiquidReportOut->pLiquidData[i].fStartOilTemp2);
               printf("Start Oil Temp3    = %f\r\n", pAtgLiquidReportOut->pLiquidData[i].fStartOilTemp3);
               printf("Start Oil Temp4    = %f\r\n", pAtgLiquidReportOut->pLiquidData[i].fStartOilTemp4);
               printf("Start Oil Temp5    = %f\r\n", pAtgLiquidReportOut->pLiquidData[i].fStartOilTemp5);
               printf("Start Oil Cubage   = %f\r\n", pAtgLiquidReportOut->pLiquidData[i].fStartOilCubage);
               printf("Start Oil Stand Cubage = %f\r\n", pAtgLiquidReportOut->pLiquidData[i].fStartOilStandCubage);
               printf("Start Empty Cubage = %f\r\n", pAtgLiquidReportOut->pLiquidData[i].fStartEmptyCubage);
               printf("Start Water Bulk   = %f\r\n", pAtgLiquidReportOut->pLiquidData[i].fStartWaterBulk);
               printf("End Date           = %s\r\n", pAtgLiquidReportOut->pLiquidData[i].strEndDate);
               printf("End Time           = %s\r\n", pAtgLiquidReportOut->pLiquidData[i].strEndTime);
               printf("End Oil Height     = %f\r\n", pAtgLiquidReportOut->pLiquidData[i].fEndOilHeight);
               printf("End Water Height   = %f\r\n", pAtgLiquidReportOut->pLiquidData[i].fEndWaterHeight);
               printf("End Oil Temp.      = %f\r\n", pAtgLiquidReportOut->pLiquidData[i].fEndOilTemp);
               printf("End Oil Temp1      = %f\r\n", pAtgLiquidReportOut->pLiquidData[i].fEndOilTemp1);
               printf("End Oil Temp2      = %f\r\n", pAtgLiquidReportOut->pLiquidData[i].fEndOilTemp2);
               printf("End Oil Temp3      = %f\r\n", pAtgLiquidReportOut->pLiquidData[i].fEndOilTemp3);
               printf("End Oil Temp4      = %f\r\n", pAtgLiquidReportOut->pLiquidData[i].fEndOilTemp4);
               printf("End Oil Temp5      = %f\r\n", pAtgLiquidReportOut->pLiquidData[i].fEndOilTemp5);
               printf("End Oil Cubage   = %f\r\n", pAtgLiquidReportOut->pLiquidData[i].fEndOilCubage);
               printf("End Oil Stand Cubage = %f\r\n", pAtgLiquidReportOut->pLiquidData[i].fEndOilStandCubage);
               printf("End Empty Cubage = %f\r\n", pAtgLiquidReportOut->pLiquidData[i].fEndEmptyCubage);
               printf("End Water Bulk   = %f\r\n", pAtgLiquidReportOut->pLiquidData[i].fEndWaterBulk);
            }
         }
      }
   }
   if (pAtgLiquidReportOut != NULL)
   {
      if (pAtgLiquidReportOut->pLiquidData!= NULL)   
      {                           
         free(pAtgLiquidReportOut->pLiquidData);   
      }                           
      free(pAtgLiquidReportOut);
   }

   return ret;
}

int main(int argc, char* argv[])
{
   void *pvSO = NULL;
   char *pszError = NULL;
   int ret = 0, iLoops = 0, iErrors = 0;
   struct atg_init_in_t atgInitIn;


   strcpy(atgInitIn.strDeviceType, g_pszDeviceType);
   atgInitIn.uConnMode = g_iConnMode;

   strcpy(atgInitIn.strSerialAddress, g_pszSerialAddress);
   strcpy(atgInitIn.strSerialBaudRate, g_pszSerialBaudRate);
   strcpy(atgInitIn.strSerialStopBit, g_pszSerialStopBit);
   strcpy(atgInitIn.strSerialCheckBit, g_pszSerialCheckBit);
   strcpy(atgInitIn.strSerialDataBit, g_pszSerialDataBit);

   strcpy(atgInitIn.strIPAddress, g_pszIPAddress);
   strcpy(atgInitIn.strIPPort, g_pszIPPort);

   strcpy(atgInitIn.strLogPath, g_pszLogPath);

   if (argc > 1)
   {
      if (strchr(argv[1], '?') == argv[1] || strstr(argv[1], "-h") == argv[1] || strstr(argv[1], "--help") == argv[1])
      {
         printf("\r\n%s usage: %s [device type] [log path] [connection mode] ...\r\n", argv[0], argv[0]);
         printf("Serial port usage: %s [device type] [log path] [0] [serial address] [baud rate] [data bits] [stop bits] [parity bit]\r\n", argv[0]);
         printf("e.g. %s VR_TLS-4 ./log 0\r\n", argv[0]);
         printf("e.g. %s VR_TLS-4 ./log 0 /dev/ttyS0\r\n", argv[0]);
         printf("e.g. %s VR_TLS-4 ./log 0 /dev/ttyS0 9600\r\n", argv[0]);
         printf("e.g. %s VR_TLS-4 ./log 0 /dev/ttyS0 9600 7\r\n", argv[0]);
         printf("e.g. %s VR_TLS-4 ./log 0 /dev/ttyS0 9600 7 1\r\n", argv[0]);
         printf("e.g. %s VR_TLS-4 ./log 0 /dev/ttyS0 9600 7 1 O\r\n", argv[0]);
         printf("Ethernet usage: %s [device type] [log path] [1] [IP address] [port]\r\n", argv[0]);
         printf("e.g. %s VR_TLS-4 ./log 1\r\n", argv[0]);
         printf("e.g. %s VR_TLS-4 ./log 1 10.20.34.21\r\n", argv[0]);
         printf("e.g. %s VR_TLS-4 ./log 1 10.20.34.21 10001\r\n", argv[0]);
         printf("Default usage: %s equals %s VR_TLS-4 ./log 1 10.20.34.21 10001 \r\n", argv[0], argv[0]);
         return 0;
      }
      else
      {
         strcpy(atgInitIn.strDeviceType, argv[1]);
      }
   }
   if (argc > 2)
   {
      strcpy(atgInitIn.strLogPath, argv[2]);
   }
   if (argc > 3)
   {
      atgInitIn.uConnMode = atoi(argv[3]);
      switch (atgInitIn.uConnMode)
      {
         case CommunicationMode_SerialPort:
            {
              switch (argc)
              {
                 case 9: strcpy(atgInitIn.strSerialCheckBit, argv[8]);
                 case 8: strcpy(atgInitIn.strSerialStopBit, argv[7]);
                 case 7: strcpy(atgInitIn.strSerialDataBit, argv[6]);
                 case 6: strcpy(atgInitIn.strSerialBaudRate, argv[5]);
                 case 5: strcpy(atgInitIn.strSerialAddress, argv[4]); break; 
                 default:;
              }
            }
            break;
         case CommunicationMode_Ethernet:
            {
              switch (argc)
              {
                 case 6: strcpy(atgInitIn.strIPPort, argv[5]);
                 case 5: strcpy(atgInitIn.strIPAddress, argv[4]); break; 
                 default:;
              }
            }
            break;
         default:;
      }
   }

   pvSO = dlopen(pszSharedObjectFile, RTLD_LAZY);
   if (NULL == pvSO)
   {
      pszError = dlerror();
      printf("Load shared object \"%s\" failed: %s\r\n", pszSharedObjectFile, (pszError != NULL ? pszError : "Unknown"));
      return 1;
   }

   printf("Load shared object \"%s\" successful. Reference address is 0x%08X\r\n", pszSharedObjectFile, (int)pvSO);
   
   do 
   {
      dlerror();
      atg_init = (int (*)(const void *))dlsym(pvSO, "atg_init");
      pszError = dlerror();
      if (pszError != NULL)
      {
         printf("Get function \"atg_init\" failed. Error: %s\r\n", pszError);
         break;
      }
      else
      {
         printf("Get function \"atg_init\" successful. Reference address is 0x%08X\r\n", (int)atg_init);      
      }

      dlerror();
      atg_operate = (int (*)(const char*, const void*, void**))dlsym(pvSO, "atg_operate");
      pszError = dlerror();
      if (pszError != NULL)
      {
         printf("Get function \"atg_operate\" failed. Error: %s\r\n", pszError);
         break;
      }
      else
      {
         printf("Get function \"atg_operate\" successful. Reference address is 0x%08X\r\n", (int)atg_operate);
      }

      dlerror();
      atg_clear = (int (*)(void))dlsym(pvSO, "atg_clear");
      pszError = dlerror();
      if (pszError != NULL)
      {
         printf("Get function \"atg_clear\" failed. Error: %s\r\n", pszError);
         break;
      }
      else
      {
         printf("Get function \"atg_clear\" successful. Reference address is 0x%08X\r\n", (int)atg_clear);
      }      


      if ((ret = atg_init(&atgInitIn)) == 0)
      {
         g_runflag = 1;

         signal(SIGINT, signal_interrupt);
         for (iLoops = 0; g_runflag > 0; iLoops++)
         {
            if (g_runflag > 0 && (ret = get_liquidreport()) != 0)
            {
               if (++iErrors > g_iMaximumErrors) break;
            }

            if (iLoops % (g_iOperationInterval / g_iPollInterval + 1) == 0)
            {
               if (g_runflag > 0 && (ret = start_liquid()) != 0)
               {
                  if (++iErrors > g_iMaximumErrors) break;
               }
            }
            else if (iLoops % (g_iOperationInterval / g_iPollInterval + 1) == g_iOperationInterval / g_iPollInterval)
            {
               if (g_runflag > 0 && (ret = stop_liquid()) != 0)
               {
                  if (++iErrors > g_iMaximumErrors) break;
               }
            }
            else
            {
            }

            sleep(g_iPollInterval);
         }

         g_runflag = 0;
      }
      else
      {
         printf("Initialize failed. atg_init(%08X) = %d\r\n", (int)&atgInitIn, ret);
         printf("strDeviceType     = %s\r\n", atgInitIn.strDeviceType);
         printf("uConnMode         = %d\r\n", atgInitIn.uConnMode);
         switch (atgInitIn.uConnMode)
         {
            case CommunicationMode_SerialPort:
               {
                  printf("strSerialAddress  = %s\r\n", atgInitIn.strSerialAddress);
                  printf("strSerialBaudRate = %s\r\n", atgInitIn.strSerialBaudRate);
                  printf("strSerialStopBit  = %s\r\n", atgInitIn.strSerialStopBit);
                  printf("strSerialCheckBit = %s\r\n", atgInitIn.strSerialCheckBit);
                  printf("strSerialDataBit  = %s\r\n", atgInitIn.strSerialDataBit);
               }
               break;
            case CommunicationMode_Ethernet:
               {
                  printf("strIPAddress      = %s\r\n", atgInitIn.strIPAddress);
                  printf("strIPPort         = %s\r\n", atgInitIn.strIPPort);
               }
               break;
            default:;
         }
         printf("strLogPath        = %s\r\n", atgInitIn.strLogPath);
      }

      ret = atg_clear();
      if (ret != 0)
      {
         printf("Clear failed. atg_clear() = %d\r\n", ret);
      }
   } while (0);   

   dlclose(pvSO);
   printf("Unload shared object \"%s\".\r\n", pszSharedObjectFile);

   return 0;
}

