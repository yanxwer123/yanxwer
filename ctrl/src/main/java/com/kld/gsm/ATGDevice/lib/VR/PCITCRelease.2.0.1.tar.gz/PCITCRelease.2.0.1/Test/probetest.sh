#!/bin/sh
rm -f ./probetest ./probetest.o core*
echo "Compiling probetest.c ..."
gcc probetest.c -I../VRIF/PCITC/ -Wall -g -lm -lc -lpthread -o probetest -ldl
echo "Compile probetest.c over"

echo "Execute ./probetest ..."

if [ $# -gt 0 ]; then
	./probetest $1
else
	./probetest
fi

if [ $# -gt 1 ]; then
	./probetest $1 $2
fi

if [ $# -gt 2 ]; then
	./probetest $1 $2 $3
fi

if [ $# -gt 3 ]; then
	./probetest $1 $2 $3 $4
fi

if [ $# -gt 4 ]; then
	./probetest $1 $2 $3 $4 $5
fi

if [ $# -gt 5 ]; then
	./probetest $1 $2 $3 $4 $5 $6
fi

if [ $# -gt 6 ]; then
	./probetest $1 $2 $3 $4 $5 $6 $7
fi

if [ $# -gt 7 ]; then
	./probetest $1 $2 $3 $4 $5 $6 $7 $8
fi

if [ $# -gt 8 ]; then
	./probetest $1 $2 $3 $4 $5 $6 $7 $8 $9
fi

if [ $# -gt 9 ]; then
	echo "Too many parameters"
	exit 0
fi
