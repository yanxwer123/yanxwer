#include <dlfcn.h>
#include <stdio.h>
#include <stdlib.h>
#include <signal.h>
#include <malloc.h>
#include <unistd.h>
#include <string.h>
#include <time.h>
#include <pthread.h>
#include "VRATGInterface.h"

#define STOCK_ENABLED         1
#define ALARM_ENABLED         1
#define FAILURE_ENABLED       1
#define DEVICEINFO_ENABLED    1
#define SETPROBE_ENABLED      1
#define HIGHTOLITER_ENABLED   1
#define POWERRECORD_ENABLED   1


#ifdef __LAB_DEBUGGING__
static const char* pszSharedObjectFile = "../VRIF/PCITC/ATGLib.so.2.0.0";
#else
static const char* pszSharedObjectFile = "../VRIF/PCITC/ATGLib.so";
#endif // #ifdef __LAB_DEBUGGING__

static const int g_iOilCans = 4;

static const int g_iPollInterval = 30;
static const int g_iSetInterval  = 120;

static const char* g_pszDeviceType = "VR_TLS-IB";
static const int g_iConnMode = CommunicationMode_SerialPort;

static const char* g_pszSerialAddress = "/dev/ttyS0";
static const char* g_pszSerialBaudRate = "2400";
static const char* g_pszSerialStopBit = "1";
static const char* g_pszSerialCheckBit = "E";
static const char* g_pszSerialDataBit = "7";

static const char* g_pszIPAddress = "10.20.34.21";
static const char* g_pszIPPort = "10001";

static const char* g_pszLogPath = "./log";

static const time_t g_tStartTimeOffset = -90 * 24 * 3600;
static const int g_iReqCount = 300;

static const int g_iMaximumErrors = 10000;

static int g_runflag = 1;

void signal_interrupt(int sig)
{
   if (g_runflag != 0)
   {
      g_runflag = 0;   
      printf("Exit by <Ctrl + C> pressed\r\n");
   }
}

int get_stock(void)
{
   int ret = 0, i = 0;
   struct atg_stock_in_t atgStockIn;
   struct atg_oilcan_data_in_t atgOilCanDataIn[g_iOilCans];
   struct atg_stock_out_t* pAtgStockOut = NULL;   
   struct tm* p = NULL;
   time_t t = 0;   

   atgStockIn.pOilCanData = atgOilCanDataIn;
   atgStockIn.uCount = g_iOilCans;

   printf("\r\n--------------------------------------------\r\n");
   t = time(NULL);
   p = localtime(&t);
   printf("Current time: %04d-%02d-%02d %02d:%02d:%02d\r\n\r\n", p->tm_year + 1900,
                                                                 p->tm_mon + 1,    
                                                                 p->tm_mday,       
                                                                 p->tm_hour,       
                                                                 p->tm_min,        
                                                                 p->tm_sec); 
   for (i = 0; i < atgStockIn.uCount; i++)
   {
      atgStockIn.pOilCanData[i].uOilCanNo = i + 1;
      printf("Oil can %d stock.\r\n", atgStockIn.pOilCanData[i].uOilCanNo);
   }
   
   ret = atg_operate(ATG_OPE_GETSTOCK, &atgStockIn, (void**)&pAtgStockOut);
   if (ret != 0)
   {
      printf("\r\nGet stock failed. atg_operate(%s, %08X, %08X) = %d\r\n", ATG_OPE_GETSTOCK, (int)&atgStockIn, (int)&pAtgStockOut, ret);
   }
   else
   {
      if (pAtgStockOut != NULL)
      {
         if (pAtgStockOut->pStockData != NULL)
         {
            for (i = 0; i < pAtgStockOut->uRetCount; i++)
            {
               printf("\r\n[-> Stock count = %d\r\n", pAtgStockOut->uRetCount);
               printf("============================================\r\n");
               printf("Stock data [%d]\r\n\r\n", i + 1);
               printf("Oil Can No       = %d\r\n", pAtgStockOut->pStockData[i].uOilCanNo);
               printf("Date             = %s\r\n", pAtgStockOut->pStockData[i].strDate);
               printf("Time             = %s\r\n", pAtgStockOut->pStockData[i].strTime);
               printf("Oil Cubage       = %f\r\n", pAtgStockOut->pStockData[i].fOilCubage);
               printf("Oil Stand Cubage = %f\r\n", pAtgStockOut->pStockData[i].fOilStandCubage);
               printf("Empty Cubage     = %f\r\n", pAtgStockOut->pStockData[i].fEmptyCubage);
               printf("Total Height     = %f\r\n", pAtgStockOut->pStockData[i].fTotalHeight);
               printf("Water Height     = %f\r\n", pAtgStockOut->pStockData[i].fWaterHeight);
               printf("Oil Temp.        = %f\r\n", pAtgStockOut->pStockData[i].fOilTemp);
               printf("Oil Temp 1       = %f\r\n", pAtgStockOut->pStockData[i].fOilTemp1);
               printf("Oil Temp 2       = %f\r\n", pAtgStockOut->pStockData[i].fOilTemp2);
               printf("Oil Temp 3       = %f\r\n", pAtgStockOut->pStockData[i].fOilTemp3);
               printf("Oil Temp 4       = %f\r\n", pAtgStockOut->pStockData[i].fOilTemp4);
               printf("Oil Temp 5       = %f\r\n", pAtgStockOut->pStockData[i].fOilTemp5);
               printf("Water Bulk       = %f\r\n", pAtgStockOut->pStockData[i].fWaterBulk);
               printf("Apparent Density = %f\r\n", pAtgStockOut->pStockData[i].fApparentDensity);
               printf("Stand Density    = %f\r\n", pAtgStockOut->pStockData[i].fStandDensity);
            }
         }
      }
   }
   if (pAtgStockOut != NULL)
   {
      if (pAtgStockOut->pStockData != NULL)
      {
         free(pAtgStockOut->pStockData);
      }
      free(pAtgStockOut);
   }

   return ret;
}

int get_alarm(void)
{
   int ret = 0, i = 0;
   struct atg_alarm_in_t atgAlarmIn;
   struct atg_alarm_data_in_t atgAlarmDataIn[g_iOilCans];
   struct atg_alarm_out_t* pAtgAlarmOut = NULL;   
   struct tm* p = NULL;
   time_t t = 0;

   atgAlarmIn.pAlarmData = atgAlarmDataIn;
   atgAlarmIn.uCount = g_iOilCans;

   printf("\r\n--------------------------------------------\r\n");
   t = time(NULL);
   p = localtime(&t);
   printf("Current time: %04d-%02d-%02d %02d:%02d:%02d\r\n\r\n", p->tm_year + 1900,
                                                                 p->tm_mon + 1,    
                                                                 p->tm_mday,       
                                                                 p->tm_hour,       
                                                                 p->tm_min,        
                                                                 p->tm_sec); 
   for (i = 0; i < atgAlarmIn.uCount; i++)
   {      
      atgAlarmIn.pAlarmData[i].uOilCanNo = i + 1;
      t = time(NULL);
      t += g_tStartTimeOffset;
      p = localtime(&t);
      sprintf(atgAlarmIn.pAlarmData[i].strDateTime, "%04d%02d%02d%02d%02d%02d", p->tm_year + 1900,
                                                                                p->tm_mon + 1,    
                                                                                p->tm_mday,       
                                                                                p->tm_hour,       
                                                                                p->tm_min,        
                                                                                p->tm_sec);       
      atgAlarmIn.pAlarmData[i].uReqCount = g_iReqCount;

      printf("Oil can %d alarm start time \"%s\", required count = %d\r\n", atgAlarmIn.pAlarmData[i].uOilCanNo, 
                                                                            atgAlarmIn.pAlarmData[i].strDateTime,
                                                                            atgAlarmIn.pAlarmData[i].uReqCount);
   }

   ret = atg_operate(ATG_OPE_GETALARM, &atgAlarmIn, (void**)&pAtgAlarmOut);
   if (ret != 0)
   {
      printf("\r\nGet alarm failed. atg_operate(%s, %08X, %08X) = %d\r\n", ATG_OPE_GETALARM, (int)&atgAlarmIn, (int)&pAtgAlarmOut, ret);
   }
   else
   {
      if (pAtgAlarmOut != NULL)
      {
         if (pAtgAlarmOut->pAlarmData != NULL)
         {
            for (i = 0; i < pAtgAlarmOut->uRetCount; i++)
            {
               printf("\r\n[-> Alarm count = %d\r\n", pAtgAlarmOut->uRetCount);
               printf("============================================\r\n");
               printf("Alarm data [%d]\r\n\r\n", i + 1);
               printf("Oil Can No  = %d\r\n", pAtgAlarmOut->pAlarmData[i].uOilCanNo);
               printf("Date        = %s\r\n", pAtgAlarmOut->pAlarmData[i].strDate);
               printf("Time        = %s\r\n", pAtgAlarmOut->pAlarmData[i].strTime);
               printf("Alarm Type  = %s\r\n", pAtgAlarmOut->pAlarmData[i].strAlarmType);
               printf("Alarm State = %s\r\n", pAtgAlarmOut->pAlarmData[i].strAlarmState);
               printf("Remark      = %s\r\n", pAtgAlarmOut->pAlarmData[i].strRemark);
               printf("Report      = %s\r\n", pAtgAlarmOut->pAlarmData[i].strReport);
            }
         }
      }
   }
   if (pAtgAlarmOut != NULL)
   {
      if (pAtgAlarmOut->pAlarmData != NULL)
      {
         free(pAtgAlarmOut->pAlarmData);
      }
      free(pAtgAlarmOut);
   }

   return ret;
}

int get_failure(void)
{
   int ret = 0, i = 0;
   struct atg_failure_in_t atgFailureIn;
   struct atg_failure_data_in_t atgFailureDataIn[g_iOilCans];
   struct atg_failure_out_t* pAtgFailureOut = NULL;   
   struct tm* p = NULL;
   time_t t = 0;

   atgFailureIn.pFailureData = atgFailureDataIn;
   atgFailureIn.uCount = g_iOilCans;

   printf("\r\n--------------------------------------------\r\n");
   t = time(NULL);
   p = localtime(&t);
   printf("Current time: %04d-%02d-%02d %02d:%02d:%02d\r\n\r\n", p->tm_year + 1900,
                                                                 p->tm_mon + 1,    
                                                                 p->tm_mday,       
                                                                 p->tm_hour,       
                                                                 p->tm_min,        
                                                                 p->tm_sec); 
   for (i = 0; i < atgFailureIn.uCount; i++)
   {      
      atgFailureIn.pFailureData[i].uOilCanNo = i + 1;
      t = time(NULL);
      t += g_tStartTimeOffset;
      p = localtime(&t);
      sprintf(atgFailureIn.pFailureData[i].strDateTime, "%04d%02d%02d%02d%02d%02d", p->tm_year + 1900,
                                                                                    p->tm_mon + 1,    
                                                                                    p->tm_mday,       
                                                                                    p->tm_hour,       
                                                                                    p->tm_min,        
                                                                                    p->tm_sec);        
      atgFailureIn.pFailureData[i].uReqCount = g_iReqCount;

      printf("Oil can %d failure start time \"%s\", required count = %d\r\n", atgFailureIn.pFailureData[i].uOilCanNo, 
                                                                              atgFailureIn.pFailureData[i].strDateTime,
                                                                              atgFailureIn.pFailureData[i].uReqCount);
   }

   ret = atg_operate(ATG_OPE_GETFAILURE, &atgFailureIn, (void**)&pAtgFailureOut);
   if (ret != 0)
   {
      printf("\r\nGet failure failed. atg_operate(%s, %08X, %08X) = %d\r\n", ATG_OPE_GETFAILURE, (int)&atgFailureIn, (int)&pAtgFailureOut, ret);
   }
   else
   {
      if (pAtgFailureOut != NULL)
      {
         if (pAtgFailureOut->pFailureData != NULL)
         {
            for (i = 0; i < pAtgFailureOut->uRetCount; i++)
            {
               printf("\r\n[-> Failure count = %d\r\n", pAtgFailureOut->uRetCount);
               printf("============================================\r\n");
               printf("Failure data [%d]\r\n\r\n", i + 1);
               printf("Oil Can No   = %d\r\n", pAtgFailureOut->pFailureData[i].uOilCanNo);
               printf("Date         = %s\r\n", pAtgFailureOut->pFailureData[i].strDate);
               printf("Time         = %s\r\n", pAtgFailureOut->pFailureData[i].strTime);
               printf("Device Type  = %s\r\n", pAtgFailureOut->pFailureData[i].strDeviceType);
               printf("Failure Type = %s\r\n", pAtgFailureOut->pFailureData[i].strFailureType);
               printf("Equip. Code  = %s\r\n", pAtgFailureOut->pFailureData[i].strEquipCode);
               printf("Fail Code    = %s\r\n", pAtgFailureOut->pFailureData[i].strFailCode);
               printf("Equip. Brand = %s\r\n", pAtgFailureOut->pFailureData[i].strEquipBrand);
               printf("Probe Model  = %s\r\n", pAtgFailureOut->pFailureData[i].strProbeModel);
               printf("Remark       = %s\r\n", pAtgFailureOut->pFailureData[i].strRemark);
            }
         }
      }
   }
   if (pAtgFailureOut != NULL)
   {
      if (pAtgFailureOut->pFailureData != NULL)
      {
         free(pAtgFailureOut->pFailureData);
      }
      free(pAtgFailureOut);
   }

   return ret;
} 

int get_deviceinfo(struct atg_device_out_t** ppAtgDeviceOut)
{
   int ret = 0, i = 0;
   struct atg_device_in_t atgDeviceIn;
   struct atg_oilcan_data_in_t atgOilCanDataIn[g_iOilCans];
   struct atg_device_out_t* pAtgDeviceOut = NULL;   
   struct tm* p = NULL;
   time_t t = 0;

   atgDeviceIn.pOilCanData = atgOilCanDataIn;
   atgDeviceIn.uCount = g_iOilCans;

   printf("\r\n--------------------------------------------\r\n");
   t = time(NULL);
   p = localtime(&t);
   printf("Current time: %04d-%02d-%02d %02d:%02d:%02d\r\n\r\n", p->tm_year + 1900,
                                                                 p->tm_mon + 1,    
                                                                 p->tm_mday,       
                                                                 p->tm_hour,       
                                                                 p->tm_min,        
                                                                 p->tm_sec); 
   for (i = 0; i < atgDeviceIn.uCount; i++)
   {      
      atgDeviceIn.pOilCanData[i].uOilCanNo = i + 1;
      printf("Oil can %d device data.\r\n", atgDeviceIn.pOilCanData[i].uOilCanNo);
   }

   ret = atg_operate(ATG_OPE_GETDEVICEINFO, &atgDeviceIn, (void**)&pAtgDeviceOut);
   if (ret != 0)
   {
      printf("\r\nGet device info failed. atg_operate(%s, %08X, %08X) = %d\r\n", ATG_OPE_GETDEVICEINFO, (int)&atgDeviceIn, (int)&pAtgDeviceOut, ret);
   }
   else
   {
      if (pAtgDeviceOut != NULL)
      {
         printf("\r\n[-> Device info\r\n");
         printf("============================================\r\n");
         printf("Device model   = %s\r\n", pAtgDeviceOut->strDeviceModel);
         printf("Equip. code    = %s\r\n", pAtgDeviceOut->strEquipCode);
         printf("System version = %s\r\n", pAtgDeviceOut->strSysVersion);
         printf("Make date      = %s\r\n", pAtgDeviceOut->strMakeDate);
         if (pAtgDeviceOut->pDeviceData != NULL)
         {
            for (i = 0; i < pAtgDeviceOut->uRetCount; i++)
            {
               printf("\r\n[-> Device data count = %d\r\n", pAtgDeviceOut->uRetCount);
               printf("============================================\r\n");
               printf("Device data [%d]\r\n\r\n", i + 1);
               printf("Oil Can No  = %d\r\n", pAtgDeviceOut->pDeviceData[i].uOilCanNo);
               printf("Probe No    = %s\r\n", pAtgDeviceOut->pDeviceData[i].strProbeNo);
               printf("Probe Model = %s\r\n", pAtgDeviceOut->pDeviceData[i].strProbeModel);
            }
         }
         *ppAtgDeviceOut = pAtgDeviceOut;
      }
   }

   return ret;
}

struct OilData
{
   char* pszType;
   char* pszNo;
   char* pszName;
};
static const struct OilData g_arrOilData[8] = { { "1902", "60000001", "90#����" },
                                                { "1000", "60000002", "93#����" },
                                                { "1911", "60000003", "97#����" },
                                                { "2000", "60000004", "0#����" },
                                                { "1912", "60000005", "92#����" },
                                                { "1914", "60000006", "95#����" },
                                                { "1915", "60000007", "98#����" },
                                                { "2901", "60000008", "-10#����" } };
int set_probe(struct atg_device_out_t* pAtgDeviceOut)
{
   int ret = 0, i = 0;
   struct atg_probecan_in_t atgProbeCanIn;
   struct atg_probecan_data_in_t atgProbeCanDataIn[g_iOilCans];
   struct tm* p = NULL;
   time_t t = 0;

   atgProbeCanIn.pProbeCanData = atgProbeCanDataIn;
   atgProbeCanIn.uCount = pAtgDeviceOut->uRetCount;

   printf("\r\n--------------------------------------------\r\n");
   t = time(NULL);
   p = localtime(&t);
   printf("Current time: %04d-%02d-%02d %02d:%02d:%02d\r\n\r\n", p->tm_year + 1900,
                                                                 p->tm_mon + 1,    
                                                                 p->tm_mday,       
                                                                 p->tm_hour,       
                                                                 p->tm_min,        
                                                                 p->tm_sec); 
   for (i = 0; i < atgProbeCanIn.uCount; i++)
   {
      atgProbeCanIn.pProbeCanData[i].strDeviceModel[0] = '\0';
      strcpy(atgProbeCanIn.pProbeCanData[i].strProbeNo, pAtgDeviceOut->pDeviceData[i].strProbeNo);
      atgProbeCanIn.pProbeCanData[i].uProbePort = 0;
      atgProbeCanIn.pProbeCanData[i].uOilCanNo = pAtgDeviceOut->uRetCount - i;
      strcpy(atgProbeCanIn.pProbeCanData[i].strOilType, g_arrOilData[i % 8].pszType);
      strcpy(atgProbeCanIn.pProbeCanData[i].strOilNo, g_arrOilData[i % 8].pszNo);
      strcpy(atgProbeCanIn.pProbeCanData[i].strOilName, g_arrOilData[i % 8].pszName);

      printf("\r\nProbe %s set data:\r\n", atgProbeCanIn.pProbeCanData[i].strProbeNo);
      printf("Device model: %s\r\n", atgProbeCanIn.pProbeCanData[i].strDeviceModel);
      printf("Probe port = %d\r\n", atgProbeCanIn.pProbeCanData[i].uProbePort);
      printf("Oil Can No = %d\r\n", atgProbeCanIn.pProbeCanData[i].uOilCanNo);
      printf("Oil type: %s\r\n", atgProbeCanIn.pProbeCanData[i].strOilType);                                      
      printf("Oil No:   %s\r\n", atgProbeCanIn.pProbeCanData[i].strOilNo);
      printf("Oil name: %s\r\n", atgProbeCanIn.pProbeCanData[i].strOilName);
   }

   ret = atg_param(ATG_OPE_SETPROBE, &atgProbeCanIn);
   if (ret != 0)
   {
      printf("\r\nSet probe data failed. atg_param(%s, %08X) = %d\r\n", ATG_OPE_SETPROBE, (int)&atgProbeCanIn, ret);
   }
   else
   {
      printf("\r\n[-> Set probe data\r\n");
      printf("============================================\r\n");
      printf("Successful\r\n\r\n");
   }

   return ret;
}

int high_toliter(void)
{
   int ret = 0;
   struct atg_hightoliter_in_t *pHighToLiterIn = NULL;
   struct atg_hightoliter_out_t *pHighToLiterOut = NULL;
   struct tm* p = NULL;
   time_t t = 0;

   printf("\r\n--------------------------------------------\r\n");
   t = time(NULL);
   p = localtime(&t);
   printf("Current time: %04d-%02d-%02d %02d:%02d:%02d\r\n\r\n", p->tm_year + 1900,
                                                                 p->tm_mon + 1,    
                                                                 p->tm_mday,       
                                                                 p->tm_hour,       
                                                                 p->tm_min,        
                                                                 p->tm_sec); 

   ret = atg_operate(ATG_OPE_HIGHTOLITER, pHighToLiterIn, (void**)&pHighToLiterOut);
   if (ret != 0)
   {
      printf("\r\nHigh to liter failed. atg_operate(%s, %08X, %08X) = %d\r\n", ATG_OPE_HIGHTOLITER, (int)pHighToLiterIn, (int)&pHighToLiterOut, ret);
   }
   else
   {
      printf("\r\n[-> High to Liter\r\n");
      printf("============================================\r\n");
      printf("Successful\r\n\r\n");
   }

   return ret;
}

int get_powerrecord(void)
{
   int ret = 0;
   struct atg_powerrecord_in_t *pPowerRecordIn = NULL;
   struct atg_powerrecord_out_t *pPowerRecordOut = NULL;
   struct tm* p = NULL;
   time_t t = 0;

   printf("\r\n--------------------------------------------\r\n");
   t = time(NULL);
   p = localtime(&t);
   printf("Current time: %04d-%02d-%02d %02d:%02d:%02d\r\n\r\n", p->tm_year + 1900,
                                                                 p->tm_mon + 1,    
                                                                 p->tm_mday,       
                                                                 p->tm_hour,       
                                                                 p->tm_min,        
                                                                 p->tm_sec); 

   ret = atg_operate(ATG_OPE_GETPOWERRECORD, pPowerRecordIn, (void**)&pPowerRecordOut);
   if (ret != 0)
   {
      printf("\r\nGet power record failed. atg_operate(%s, %08X, %08X) = %d\r\n", ATG_OPE_GETPOWERRECORD, (int)pPowerRecordIn, (int)&pPowerRecordOut, ret);
   }
   else
   {
      printf("\r\n[-> Get power record\r\n");
      printf("============================================\r\n");
      printf("Successful\r\n\r\n");
   }

   return ret;
}

int main(int argc, char* argv[])
{
   void *pvSO = NULL;
   char *pszError = NULL;
   int ret = 0, iLoops = 0, iErrors = 0;
   struct atg_init_in_t atgInitIn;
   struct atg_device_out_t* pAtgDeviceOut = NULL;


   strcpy(atgInitIn.strDeviceType, g_pszDeviceType);
   atgInitIn.uConnMode = g_iConnMode;

   strcpy(atgInitIn.strSerialAddress, g_pszSerialAddress);
   strcpy(atgInitIn.strSerialBaudRate, g_pszSerialBaudRate);
   strcpy(atgInitIn.strSerialStopBit, g_pszSerialStopBit);
   strcpy(atgInitIn.strSerialCheckBit, g_pszSerialCheckBit);
   strcpy(atgInitIn.strSerialDataBit, g_pszSerialDataBit);

   strcpy(atgInitIn.strIPAddress, g_pszIPAddress);
   strcpy(atgInitIn.strIPPort, g_pszIPPort);

   strcpy(atgInitIn.strLogPath, g_pszLogPath);

   if (argc > 1)
   {
      if (strchr(argv[1], '?') == argv[1] || strstr(argv[1], "-h") == argv[1] || strstr(argv[1], "--help") == argv[1])
      {
         printf("\r\n%s usage: %s [device type] [log path] [connection mode] ...\r\n", argv[0], argv[0]);
         printf("Serial port usage: %s [device type] [log path] [0] [serial address] [baud rate] [data bits] [stop bits] [parity bit]\r\n", argv[0]);
         printf("e.g. %s VR_TLS-4 ./log 0\r\n", argv[0]);
         printf("e.g. %s VR_TLS-4 ./log 0 /dev/ttyS0\r\n", argv[0]);
         printf("e.g. %s VR_TLS-4 ./log 0 /dev/ttyS0 9600\r\n", argv[0]);
         printf("e.g. %s VR_TLS-4 ./log 0 /dev/ttyS0 9600 7\r\n", argv[0]);
         printf("e.g. %s VR_TLS-4 ./log 0 /dev/ttyS0 9600 7 1\r\n", argv[0]);
         printf("e.g. %s VR_TLS-4 ./log 0 /dev/ttyS0 9600 7 1 O\r\n", argv[0]);
         printf("Ethernet usage: %s [device type] [log path] [1] [IP address] [port]\r\n", argv[0]);
         printf("e.g. %s VR_TLS-4 ./log 1\r\n", argv[0]);
         printf("e.g. %s VR_TLS-4 ./log 1 10.20.34.21\r\n", argv[0]);
         printf("e.g. %s VR_TLS-4 ./log 1 10.20.34.21 10001\r\n", argv[0]);
         printf("Default usage: %s equals %s VR_TLS-4 ./log 1 10.20.34.21 10001 \r\n", argv[0], argv[0]);
         return 0;
      }
      else
      {
         strcpy(atgInitIn.strDeviceType, argv[1]);
      }
   }
   if (argc > 2)
   {
      strcpy(atgInitIn.strLogPath, argv[2]);
   }
   if (argc > 3)
   {
      atgInitIn.uConnMode = atoi(argv[3]);
      switch (atgInitIn.uConnMode)
      {
         case CommunicationMode_SerialPort:
            {
              switch (argc)
              {
                 case 9: strcpy(atgInitIn.strSerialCheckBit, argv[8]);
                 case 8: strcpy(atgInitIn.strSerialStopBit, argv[7]);
                 case 7: strcpy(atgInitIn.strSerialDataBit, argv[6]);
                 case 6: strcpy(atgInitIn.strSerialBaudRate, argv[5]);
                 case 5: strcpy(atgInitIn.strSerialAddress, argv[4]); break; 
                 default:;
              }
            }
            break;
         case CommunicationMode_Ethernet:
            {
              switch (argc)
              {
                 case 6: strcpy(atgInitIn.strIPPort, argv[5]);
                 case 5: strcpy(atgInitIn.strIPAddress, argv[4]); break; 
                 default:;
              }
            }
            break;
         default:;
      }
   }

   pvSO = dlopen(pszSharedObjectFile, RTLD_LAZY);
   if (NULL == pvSO)
   {
      pszError = dlerror();
      printf("Load shared object \"%s\" failed: %s\r\n", pszSharedObjectFile, (pszError != NULL ? pszError : "Unknown"));
      return 1;
   }

   printf("Load shared object \"%s\" successful. Reference address is 0x%08X\r\n", pszSharedObjectFile, (int)pvSO);
   
   do 
   {
      dlerror();
      atg_init = (int (*)(const void *))dlsym(pvSO, "atg_init");
      pszError = dlerror();
      if (pszError != NULL)
      {
         printf("Get function \"atg_init\" failed. Error: %s\r\n", pszError);
         break;
      }
      else
      {
         printf("Get function \"atg_init\" successful. Reference address is 0x%08X\r\n", (int)atg_init);      
      }

      dlerror();
      atg_param = (int (*)(const char*, const void*))dlsym(pvSO, "atg_param");
      pszError = dlerror();
      if (pszError != NULL)
      {
         printf("Get function \"atg_param\" failed. Error: %s\r\n", pszError);
         break;
      }
      else
      {
         printf("Get function \"atg_param\" successful. Reference address is 0x%08X\r\n", (int)atg_param);
      }

      dlerror();
      atg_operate = (int (*)(const char*, const void*, void**))dlsym(pvSO, "atg_operate");
      pszError = dlerror();
      if (pszError != NULL)
      {
         printf("Get function \"atg_operate\" failed. Error: %s\r\n", pszError);
         break;
      }
      else
      {
         printf("Get function \"atg_operate\" successful. Reference address is 0x%08X\r\n", (int)atg_operate);
      }

      dlerror();
      atg_clear = (int (*)(void))dlsym(pvSO, "atg_clear");
      pszError = dlerror();
      if (pszError != NULL)
      {
         printf("Get function \"atg_clear\" failed. Error: %s\r\n", pszError);
         break;
      }
      else
      {
         printf("Get function \"atg_clear\" successful. Reference address is 0x%08X\r\n", (int)atg_clear);
      }      


      if ((ret = atg_init(&atgInitIn)) == 0)
      {
         g_runflag = 1;

         signal(SIGINT, signal_interrupt);
         for (iLoops = 0; g_runflag > 0; iLoops++)
         {
             if (pAtgDeviceOut != NULL)
            {
               if (pAtgDeviceOut->pDeviceData != NULL)
               {
                  free(pAtgDeviceOut->pDeviceData);
               }
               free(pAtgDeviceOut);
               pAtgDeviceOut = NULL;
            }

#ifdef STOCK_ENABLED
            if (g_runflag > 0 && (ret = get_stock()) != 0)
            {
               if (++iErrors > g_iMaximumErrors) break;
            }            
#endif // #ifdef STOCK_ENABLED

#ifdef ALARM_ENABLED
            if (g_runflag > 0 && (ret = get_alarm()) != 0)
            {
               if (++iErrors > g_iMaximumErrors) break;
            }
#endif // #ifdef ALARM_ENABLED

#ifdef FAILURE_ENABLED
            if (g_runflag > 0 && (ret = get_failure()) != 0)
            {
               if (++iErrors > g_iMaximumErrors) break;
            }
#endif // #ifdef FAILURE_ENABLED
         
#ifdef DEVICEINFO_ENABLED
            if (g_runflag > 0 && (ret = get_deviceinfo(&pAtgDeviceOut)) != 0)
            {
               if (++iErrors > g_iMaximumErrors) break;
            }
#endif // #ifdef DEVICEINFO_ENABLED

            if (iLoops % (g_iSetInterval / g_iPollInterval) == 0)
            {
               if (pAtgDeviceOut != NULL)
               {
                  if (pAtgDeviceOut->pDeviceData != NULL)
                  {
#ifdef SETPROBE_ENABLED
                     if (g_runflag > 0 && (ret = set_probe(pAtgDeviceOut)) != 0)
                     {
                        if (++iErrors > g_iMaximumErrors) break;
                     }
#endif // #ifdef SETPROBE_ENABLED
                  }
               }
           }
            
            if (pAtgDeviceOut != NULL)
            {
               if (pAtgDeviceOut->pDeviceData != NULL)
               {
                  free(pAtgDeviceOut->pDeviceData);
               }
               free(pAtgDeviceOut);
               pAtgDeviceOut = NULL;
            }
          
#ifdef HIGHTOLITER_ENABLED
            if (g_runflag > 0)
            {
               high_toliter();
            }
#endif // #ifdef HIGHTOLITER_ENABLED

#ifdef POWERRECORD_ENABLED
            if (g_runflag > 0)
            {
               get_powerrecord();
            }
#endif // #ifdef POWERRECORD_ENABLED

            sleep(g_iPollInterval);
         }

         if (pAtgDeviceOut != NULL)
         {
            if (pAtgDeviceOut->pDeviceData != NULL)
            {
               free(pAtgDeviceOut->pDeviceData);
            }
            free(pAtgDeviceOut);
         }

         g_runflag = 0;
      }
      else
      {
         printf("Initialize failed. atg_init(%08X) = %d\r\n", (int)&atgInitIn, ret);
         printf("strDeviceType     = %s\r\n", atgInitIn.strDeviceType);
         printf("uConnMode         = %d\r\n", atgInitIn.uConnMode);
         switch (atgInitIn.uConnMode)
         {
            case CommunicationMode_SerialPort:
               {
                  printf("strSerialAddress  = %s\r\n", atgInitIn.strSerialAddress);
                  printf("strSerialBaudRate = %s\r\n", atgInitIn.strSerialBaudRate);
                  printf("strSerialStopBit  = %s\r\n", atgInitIn.strSerialStopBit);
                  printf("strSerialCheckBit = %s\r\n", atgInitIn.strSerialCheckBit);
                  printf("strSerialDataBit  = %s\r\n", atgInitIn.strSerialDataBit);
               }
               break;
            case CommunicationMode_Ethernet:
               {
                  printf("strIPAddress      = %s\r\n", atgInitIn.strIPAddress);
                  printf("strIPPort         = %s\r\n", atgInitIn.strIPPort);
               }
               break;
            default:;
         }
         printf("strLogPath        = %s\r\n", atgInitIn.strLogPath);
      }

      ret = atg_clear();
      if (ret != 0)
      {
         printf("Clear failed. atg_clear() = %d\r\n", ret);
      }
   } while (0);   

   dlclose(pvSO);
   printf("Unload shared object \"%s\".\r\n", pszSharedObjectFile);

   return 0;
}

