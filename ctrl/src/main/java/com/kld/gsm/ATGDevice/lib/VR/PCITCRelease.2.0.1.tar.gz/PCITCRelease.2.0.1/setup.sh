#!/bin/bash

echo "Usage: ./setup.sh [Setup Dir]"
echo "Default setup directory is /smc20"

if [ $# -gt 0 ]; then
	TARGET=$1
else
	TARGET="/smc20/gsm/lib"
fi

echo "Setup ATGLib ..."

ROOT=${TARGET%/*}
BACKUP=backuplog

mkdir $BACKUP
cp -f $ROOT/logs/????????.log ./$BACKUP
tar -czf ./$BACKUP.tar.gz ./$BACKUP
rm -r -f $BACKUP

#rm -f $ROOT/logs/????????.log
rm -f $TARGET/ATGLib.so*
rm -r -f $ROOT/Config

mkdir -p $ROOT/Config

cp -f ./VRIF/PCITC/ATGLib.so.* $TARGET/
chmod 775 $TARGET/ATGLib.so.*
ln -s -f $TARGET/ATGLib.so.* $TARGET/ATGLib.so

cp -f ./Test/Config/*.cfg $ROOT/Config
chmod 666 $ROOT/Config
chmod 666 $ROOT/Config/*

echo "Setup ATGLib accomplished."

